#!/bin/sh

logger "Received ACPI event: ${@}"

