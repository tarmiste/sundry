#!/bin/sh
ANT_HOME="/usr/share/java/ant"
export ANT_HOME
